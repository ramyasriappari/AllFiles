package com.spring.SpringGet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class SpringGetApplication {

	public static void main(String[] args) {
		WebClient webClient = WebClient.create("https://jsonplaceholder.typicode.com");
		String usersResult = webClient.get().uri("/users").headers(httpHeaders -> {
		}).retrieve().bodyToMono(String.class).block();
		System.out.println(usersResult);

	}
}
