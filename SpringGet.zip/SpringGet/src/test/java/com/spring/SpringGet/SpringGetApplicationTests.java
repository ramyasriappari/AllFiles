package com.spring.SpringGet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGetApplicationTests {

	@Test
	void contextLoads() {
	}

}
