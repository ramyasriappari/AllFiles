package com.evolution.evolution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
